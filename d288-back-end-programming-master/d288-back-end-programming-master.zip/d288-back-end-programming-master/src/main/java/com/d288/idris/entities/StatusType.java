package com.d288.idris.entities;

public enum StatusType {
    ordered,
    pending,
    cancelled
}
